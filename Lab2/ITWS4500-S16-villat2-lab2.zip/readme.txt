Tristan Villamil

Using the API was simple enough, the only real problem I had was getting the correct id from openweathermap. The one I thought they gave me didn't work, I had to find it in a roundabout way.

Using geolocation was also a simple matter of googling it, it is very well documented, which I appreciated.

Again, the one weak point was the style, but I think it looks good.