I used the Twit module to read in the twitter api because it was the most intuitive to use in my opinion.

I used fs to output the information into a JSON file which can be used as input for lab 1 (tweets.json).

The server was created using express, where the API was accessed.

Once accessed, the server passed the information back using socket.emit (the same way the query was passed to the server)

I experimented with vw in CSS, in an attempt to make the button more dynamically-sized when the page shrinks. I don't like it as much as I thought I would, I will continue experimenting.