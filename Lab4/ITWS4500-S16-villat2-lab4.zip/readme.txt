Angular took a little getting used to, but it was simple enough once the controller was working properly.

The Twitter API once set up was as simple as reading the format from the JSON file.

The media queries are in the css file, very simply it sets the width to a constant if the window is greater than that constant, and makes it 90% if it is less.